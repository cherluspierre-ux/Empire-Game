#!/usr/bin/env python3
"""Prépare le site officiel pour Render : active l'API sur la même origine et recalcule la CSP."""
import os, re, json, shutil, sys
from csp import strip_csp, add_csp

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
origin = os.environ.get("ORIGIN", "").rstrip("/")
if not re.fullmatch(r"https://[A-Za-z0-9.-]+(?::[0-9]+)?", origin):
    sys.exit("ORIGIN doit être l'URL HTTPS exacte du service Render, sans slash final.")
source = os.path.join(ROOT, "index.html")
if not os.path.isfile(source):
    sys.exit("index.html introuvable à la racine du projet.")
with open(source, encoding="utf-8") as f:
    html = strip_csp(f.read())
marker = '<script>window.EC_WEB=Object.freeze({origins:Object.freeze([%s]),api:true});</script>' % json.dumps(origin)
pattern = re.compile(r"<script\b[^>]*>[\s\S]*?window\.EC_WEB\s*=.*?</script>", re.I)
if pattern.search(html):
    html = pattern.sub(marker, html, count=1)
else:
    if "</head>" not in html:
        sys.exit("Balise </head> introuvable dans index.html.")
    html = html.replace("</head>", marker + "\n</head>", 1)
html = add_csp(html, web=True)

out = os.environ.get("PUBLIC_DIR", "/tmp/ec-public")
if os.path.isdir(out):
    shutil.rmtree(out)
os.makedirs(out, exist_ok=True)
with open(os.path.join(out, "index.html"), "w", encoding="utf-8") as f:
    f.write(html)
required = ["sw.js", "manifest.webmanifest", "icon-192.png", "icon-512.png", "icon-maskable-512.png", "apple-touch-icon.png", "confidentialite.html", "robots.txt"]
for name in required:
    src = os.path.join(ROOT, name)
    if not os.path.isfile(src):
        sys.exit("Fichier nécessaire manquant : " + name)
    shutil.copy2(src, os.path.join(out, name))
print("Site Render préparé :", out, "· origine :", origin)
