"""Politique de sécurité du contenu (CSP) stricte pour les versions autonomes.

- scripts : uniquement ceux du fichier, identifiés par leur empreinte SHA-256 (aucun script injecté ne s'exécute) ;
- aucune connexion réseau possible (connect-src 'none'), aucune image, police ou média externe ;
- pas de formulaire, pas de <base>, pas d'objet embarqué, pas de cadre.
Les polices Google sont retirées : le jeu utilise les polices du système.
"""
import re, hashlib, base64

def add_csp(html, web=False):
    """web=True : version servie par le serveur du jeu (connexions vers sa propre origine, service worker, manifeste)."""
    html = re.sub(r'\s*<link[^>]+fonts\.(?:googleapis|gstatic)\.com[^>]*>', '', html)
    html = re.sub(r'\s*<meta http-equiv="Content-Security-Policy"[^>]*>', '', html)
    hashes = []
    for m in re.finditer(r'<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>', html, re.S):
        h = "'sha256-" + base64.b64encode(hashlib.sha256(m.group(1).encode('utf-8')).digest()).decode() + "'"
        if h not in hashes:
            hashes.append(h)
    if web:
        pol = ("default-src 'none'; script-src " + ' '.join(hashes) + "; style-src 'unsafe-inline'; "
               "img-src 'self' data: blob:; font-src data:; media-src data: blob:; manifest-src 'self'; connect-src 'self'; "
               "base-uri 'none'; form-action 'none'; object-src 'none'; frame-src 'none'; worker-src 'self'")
    else:
        pol = ("default-src 'none'; script-src " + ' '.join(hashes) + "; style-src 'unsafe-inline'; "
               "img-src data: blob:; font-src data:; media-src data: blob:; manifest-src data:; connect-src 'none'; "
               "base-uri 'none'; form-action 'none'; object-src 'none'; frame-src 'none'; worker-src 'none'")
    tag = '<meta http-equiv="Content-Security-Policy" content="%s">' % pol
    html, n = re.subn(r'(<meta charset="[^"]*">)', lambda m: m.group(1) + '\n  ' + tag, html, count=1)
    if not n:
        html = html.replace('<head>', '<head>\n  ' + tag, 1)
    return html

def strip_csp(html):
    return re.sub(r'\s*<meta http-equiv="Content-Security-Policy"[^>]*>', '', html)
