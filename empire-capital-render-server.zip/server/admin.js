#!/usr/bin/env node
'use strict';
/**
 * Modération d'Empire Capital, à lancer sur le serveur (ou dans le conteneur) :
 *   ADMIN_TOKEN=… node server/admin.js <commande> [arguments]
 * Dans Docker :  docker compose exec game node /app/server/admin.js stats
 *
 *   stats                          chiffres clés
 *   suspects                       parties écartées par l'anti-triche (100 dernières)
 *   signalements                   joueurs signalés par les autres
 *   joueur <nom>                   fiche d'un joueur
 *   bannir <nom> [motif…]          retire le joueur du classement et l'empêche d'y revenir
 *   debannir <nom>
 *   renommer <nom> <nouveau-nom>   pseudo inapproprié
 *   lever-examen <nom>             remet au classement un joueur mis à l'écart par des signalements
 *   retirer-partie <id>            retire une partie du classement
 *   retablir-partie <id>           rétablit une partie écartée à tort (faux positif)
 *   supprimer <nom> <nom>          supprime définitivement le compte (taper le nom deux fois)
 */
const http = require('http');
const token = process.env.ADMIN_TOKEN || '', port = +process.env.ADMIN_PORT || 9091;
const [cmd, a, ...rest] = process.argv.slice(2);
const C = {
  stats: ['GET', '/stats'], suspects: ['GET', '/flagged'], signalements: ['GET', '/reports'],
  joueur: ['GET', '/user?u=' + encodeURIComponent(a || '')],
  bannir: ['POST', '/ban', { u: a, reason: rest.join(' ') || 'triche' }], debannir: ['POST', '/unban', { u: a }],
  renommer: ['POST', '/rename', { u: a, to: rest[0] }], 'lever-examen': ['POST', '/clear-review', { u: a }],
  'retirer-partie': ['POST', '/run-remove', { run: a }], 'retablir-partie': ['POST', '/run-restore', { run: a }],
  supprimer: ['POST', '/delete-user', { u: a, confirm: rest[0] }],
};
if (!C[cmd]) { console.log(require('fs').readFileSync(__filename, 'utf8').split('*/')[0].replace(/^[\s\S]*?\/\*\*\n/, '').replace(/^ \* ?/gm, '')); process.exit(cmd ? 1 : 0); }
if (token.length < 32) { console.error('ADMIN_TOKEN manquant ou trop court.'); process.exit(1); }
const [method, path, body] = C[cmd], data = body ? JSON.stringify(body) : null;
const r = http.request({ host: '127.0.0.1', port, method, path, headers: Object.assign({ Authorization: 'Bearer ' + token }, data ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } : {}) }, res => {
  let t = ''; res.on('data', c => t += c); res.on('end', () => { console.log(t); process.exit(res.statusCode === 200 ? 0 : 1); });
});
r.on('error', e => { console.error('Serveur de modération injoignable (ADMIN_TOKEN défini au démarrage du serveur ?) :', e.message); process.exit(1); });
if (data) r.write(data); r.end();
