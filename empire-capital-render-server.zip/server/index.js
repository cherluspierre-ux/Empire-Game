#!/usr/bin/env node
'use strict';
/**
 * Serveur d'Empire Capital : jeu en ligne, comptes, sauvegardes chiffrées dans le cloud, classement contrôlé.
 * Aucune dépendance externe (Node.js 20 ou plus) : rien à mettre à jour, aucun risque lié à un paquet tiers.
 *
 * Variables d'environnement :
 *   PORT (8080) · HOST (0.0.0.0) · DATA_DIR (./data) · PUBLIC_DIR (../dist/web)
 *   ORIGIN   adresse publique exacte, ex. https://jeu.exemple.fr (obligatoire en production : contrôle Host et Origin)
 *   TRUST_PROXY=1   derrière un proxy (Caddy, Nginx) qui ajoute X-Forwarded-For
 *   DEV=1    développement local en http (cookie sans « Secure », pas de HSTS)
 *   ADMIN_TOKEN (32 caractères minimum) et ADMIN_PORT (9091) : modération locale, voir admin.js
 */
const http = require('http'), path = require('path'), crypto = require('crypto');
const { Store } = require('./lib/store');
const { Limiter } = require('./lib/limits');
const { Accounts } = require('./lib/accounts');
const { Cloud, MAX_DATA } = require('./lib/cloud');
const { Board } = require('./lib/board');
const { loadSite, serveStatic, baseHeaders } = require('./lib/web');
const { createAdmin } = require('./lib/admin');
const { safeParse, Bad, V } = require('./lib/util');

const VERSION = '1.0.0';

function createServer(opt = {}) {
  const env = Object.assign({}, process.env, opt.env || {});
  const cfg = {
    dev: env.DEV === '1', origin: (env.ORIGIN || '').replace(/\/+$/, ''), trustProxy: env.TRUST_PROXY === '1',
    dataDir: path.resolve(env.DATA_DIR || path.join(__dirname, 'data')),
    publicDir: path.resolve(env.PUBLIC_DIR || path.join(__dirname, '..', 'dist', 'web')),
  };
  if (!cfg.dev && !cfg.origin) console.warn('[sécurité] ORIGIN n’est pas défini : définissez-le en production (ex. ORIGIN=https://jeu.exemple.fr).');
  const store = new Store(cfg.dataDir);
  const secret = store.secret('secret.key', 32);
  const ipTag = ip => crypto.createHmac('sha256', secret).update('ip|' + ip).digest('base64url').slice(0, 12);
  const audit = (ev, uid, extra, ip) => { try { store.append('audit.log', JSON.stringify(Object.assign({ t: new Date().toISOString(), ev, uid: uid || null, ip: ip ? ipTag(ip) : undefined }, extra || {})), 10 * 1024 * 1024); } catch (e) {} };
  const acc = new Accounts(store, secret, audit), cloud = new Cloud(store), board = new Board(store, audit, acc), lim = new Limiter();
  const site = loadSite(cfg.publicDir);
  const cookieName = cfg.dev ? 'ec_s' : '__Host-ec_s';
  const purgeAudit = () => { try { const f = store.p('audit.log.1'); if (Date.now() - require('fs').statSync(f).mtimeMs > 365 * 864e5) require('fs').unlinkSync(f); } catch (e) {} };
  purgeAudit();
  const gcT = setInterval(() => { acc.gc(); purgeAudit(); }, 3600000); gcT.unref();

  const clientIp = req => {
    if (cfg.trustProxy) { const x = String(req.headers['x-forwarded-for'] || '').split(',').map(s => s.trim()).filter(Boolean); if (x.length) return x[x.length - 1]; }
    return req.socket.remoteAddress || '?';
  };
  const cookie = req => { const m = /(?:^|;\s*)(__Host-ec_s|ec_s)=([A-Za-z0-9_-]{43})(?:;|$)/.exec(String(req.headers.cookie || '')); return m && m[1] === cookieName ? m[2] : null; };
  const setCookie = (res, tok) => res.setHeader('Set-Cookie', `${cookieName}=${tok || ''}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${tok ? 30 * 86400 : 0}${cfg.dev ? '' : '; Secure'}`);

  function send(res, status, obj, extra) {
    const body = JSON.stringify(obj);
    res.writeHead(status, Object.assign(baseHeaders(cfg), {
      'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Security-Policy': "default-src 'none'; frame-ancestors 'none'",
      'Content-Length': Buffer.byteLength(body),
    }, extra || {}));
    res.end(body);
  }
  function readJson(req, max) {
    return new Promise((resolve, reject) => {
      const ct = String(req.headers['content-type'] || '');
      if (!/^application\/json\b/.test(ct)) return reject(new Bad('content_type', 415));
      const len = +req.headers['content-length'];
      if (len > max) return reject(new Bad('too_large', 413));
      let n = 0; const parts = [];
      req.on('data', c => { n += c.length; if (n > max) { reject(new Bad('too_large', 413)); req.destroy(); } else parts.push(c); });
      req.on('end', () => { try { const o = safeParse(Buffer.concat(parts).toString('utf8') || '{}'); V.obj(o); resolve(o); } catch (e) { reject(e instanceof Bad ? e : new Bad('bad_json')); } });
      req.on('error', () => reject(new Bad('aborted')));
    });
  }
  /** Requêtes qui modifient quelque chose : même origine obligatoire (protection CSRF en plus du cookie SameSite=Strict). */
  function sameOrigin(req) {
    if (req.headers['x-ec'] !== '1') return false;
    const sfs = req.headers['sec-fetch-site'];
    if (sfs && sfs !== 'same-origin' && sfs !== 'none') return false;
    const o = req.headers.origin;
    if (o) { const want = cfg.origin || ((cfg.dev ? 'http://' : 'https://') + req.headers.host); if (o !== want) return false; }
    return true;
  }
  const need = (who) => { if (!who) throw new Bad('auth_required', 401); return who; };
  const limit = (key, perMin, burst) => { const w = lim.take(key, perMin, burst); if (w) throw new Bad('rate_limited', 429, { wait: w }); };

  /* ---------- routes ---------- */
  const R = [];
  const on = (m, re, h) => R.push({ m, re, h });
  on('GET', /^\/api\/health$/, () => ({ ok: 1, v: VERSION }));
  on('GET', /^\/api\/prelogin$/, (c) => { limit('pre|' + c.ip, 30, 30); return acc.prelogin(c.q.get('u')); });
  on('POST', /^\/api\/register$/, async (c) => {
    limit('reg|' + c.ip, 3 / 60, 5);
    const b = await c.body(4096), u = await acc.register(b);
    setCookie(c.res, acc.open(u.id, c.req.headers['user-agent'])); audit('register', u.id, null, c.ip);
    return { u: u.name, vault: u.vault, kdf: u.kdf };
  });
  on('POST', /^\/api\/login$/, async (c) => {
    limit('login|' + c.ip, 10, 10);
    const b = await c.body(4096); limit('loginu|' + String(b.u).toLowerCase().slice(0, 40), 10, 10);
    const u = await acc.verify(b.u, b.auth);
    setCookie(c.res, acc.open(u.id, c.req.headers['user-agent'])); audit('login', u.id, null, c.ip);
    return { u: u.name, vault: u.vault, kdf: u.kdf };
  });
  on('POST', /^\/api\/logout$/, (c) => { if (c.who) acc.drop(c.who.key); setCookie(c.res, ''); return { ok: 1 }; });
  on('POST', /^\/api\/logout-all$/, (c) => { const w = need(c.who); acc.dropAll(w.u.id); setCookie(c.res, ''); audit('logout_all', w.u.id, null, c.ip); return { ok: 1 }; });
  on('GET', /^\/api\/session$/, (c) => c.who ? { u: c.who.u.name, vault: c.who.u.vault, kdf: c.who.u.kdf } : { u: null });
  on('GET', /^\/api\/me$/, (c) => { const w = need(c.who); return { u: w.u.name, created: w.u.created, vault: w.u.vault, kdf: w.u.kdf, sessions: acc.count(w.u.id), banned: !!w.u.ban }; });
  on('POST', /^\/api\/password$/, async (c) => {
    const w = need(c.who); limit('pw|' + w.u.id, 5, 5);
    const b = await c.body(4096); await acc.verify(w.u.name, b.auth); await acc.changeSecret(w.u, b);
    acc.dropAll(w.u.id, w.key); audit('password_change', w.u.id, null, c.ip); return { ok: 1 };
  });
  on('POST', /^\/api\/delete-account$/, async (c) => {
    const w = need(c.who); limit('del|' + w.u.id, 5, 5);
    const b = await c.body(4096); await acc.verify(w.u.name, b.auth);
    cloud.wipe(w.u.id); board.wipe(w.u.id); acc.remove(w.u); setCookie(c.res, ''); audit('account_deleted', null, null, c.ip);
    return { ok: 1 };
  });
  on('GET', /^\/api\/export$/, (c) => { const w = need(c.who); limit('exp|' + w.u.id, 6, 6);
    return { compte: { nom: w.u.name, cree: new Date(w.u.created).toISOString(), derniere_connexion: new Date(w.u.last).toISOString() }, sauvegardes: cloud.list(w.u.id).map(s => ({ emplacement: s.slot, version: s.rev, date: new Date(s.t).toISOString(), taille: s.size, contenu: 'chiffré sur votre appareil, illisible par le serveur' })), parties_classees: board.mine(w.u.id), sessions_actives: acc.count(w.u.id) }; });
  on('GET', /^\/api\/saves$/, (c) => ({ saves: cloud.list(need(c.who).u.id) }));
  on('GET', /^\/api\/saves\/([^/]+)$/, (c, m) => { const w = need(c.who); limit('sv|' + w.u.id, 30, 30); return cloud.get(w.u.id, m[1]); });
  on('PUT', /^\/api\/saves\/([^/]+)$/, async (c, m) => { const w = need(c.who); limit('sv|' + w.u.id, 30, 30); return cloud.put(w.u.id, m[1], await c.body(MAX_DATA + 8192)); });
  on('DELETE', /^\/api\/saves\/([^/]+)$/, (c, m) => { const w = need(c.who); cloud.del(w.u.id, m[1]); return { ok: 1 }; });
  on('POST', /^\/api\/runs$/, async (c) => { const w = need(c.who); limit('run|' + w.u.id, 6, 10); return board.start(w.u, await c.body(4096)); });
  on('POST', /^\/api\/runs\/([^/]+)\/cp$/, async (c, m) => { const w = need(c.who); limit('cp|' + w.u.id, 30, 30); return board.checkpoint(w.u, m[1], await c.body(4096)); });
  on('GET', /^\/api\/board$/, (c) => { limit('board|' + c.ip, 40, 40); return board.top(c.who && c.who.u.id, { b: c.q.get('b'), d: c.q.get('d') }); });
  on('GET', /^\/api\/profile$/, (c) => { const w = need(c.who); return board.profile(w.u); });
  on('GET', /^\/api\/player$/, (c) => { limit('pl|' + c.ip, 30, 30); return board.publicProfile(V.str(c.q.get('u') || '', 1, 20)); });
  on('POST', /^\/api\/report$/, async (c) => { const w = need(c.who); limit('rep|' + w.u.id, 5, 5); const r = board.report(w.u, await c.body(1024)); audit('report', w.u.id, null, c.ip); return r; });

  async function handle(req, res) {
    const ip = clientIp(req);
    try {
      if (req.url.length > 2048) throw new Bad('uri_too_long', 414);
      if (cfg.origin) {                     // protège contre le « DNS rebinding » et les en-têtes Host forgés
        const host = String(req.headers.host || '');
        if (host !== new URL(cfg.origin).host) throw new Bad('bad_host', 421);
      }
      limit('all|' + ip, 600, 300);
      const u = new URL(req.url, 'http://x');
      let pathname; try { pathname = decodeURIComponent(u.pathname); } catch (e) { throw new Bad('bad_path'); }
      if (!pathname.startsWith('/api/')) {
        if (req.method !== 'GET' && req.method !== 'HEAD') throw new Bad('method', 405);
        return serveStatic(req, res, site, cfg, pathname);
      }
      const route = R.find(r => r.re.test(pathname) && r.m === req.method);
      if (!route) throw new Bad(R.some(r => r.re.test(pathname)) ? 'method' : 'not_found', R.some(r => r.re.test(pathname)) ? 405 : 404);
      if (req.method !== 'GET' && !sameOrigin(req)) { audit('csrf_block', null, { path: pathname }, ip); throw new Bad('forbidden_origin', 403); }
      const tok = cookie(req), who = tok ? acc.get(tok) : null;
      const ctx = { req, res, ip, q: u.searchParams, who, body: max => readJson(req, max) };
      const out = await route.h(ctx, route.re.exec(pathname));
      send(res, 200, out);
    } catch (e) {
      if (!(e instanceof Bad)) { console.error('[erreur]', e && e.stack || e); e = new Bad('server_error', 500); }
      if (res.headersSent) return res.end();
      const extra = e.status === 429 && e.extra && e.extra.wait ? { 'Retry-After': String(e.extra.wait) } : {};
      if (e.status === 405) extra.Allow = 'GET, HEAD';
      send(res, e.status, Object.assign({ error: e.code }, e.extra || {}), extra);
    }
  }

  const server = http.createServer({ requestTimeout: 30000, headersTimeout: 15000, maxHeaderSize: 16384 }, (req, res) => { handle(req, res); });
  server.keepAliveTimeout = 5000;
  server.on('clientError', (err, sock) => { try { sock.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n'); } catch (e) {} });
  server.flushAll = () => { acc.flush(); board.flush(); };
  server.cfg = cfg; server.site = site; server.board = board; server.acc = acc;
  const tok = env.ADMIN_TOKEN || '';
  if (tok && tok.length < 32) console.warn('[sécurité] ADMIN_TOKEN trop court (32 caractères minimum) : modération désactivée.');
  server.admin = tok.length >= 32 ? createAdmin({ token: tok, acc, board, cloud, audit }) : null;
  server.adminPort = +env.ADMIN_PORT || 9091;
  return server;
}

if (require.main === module) {
  const port = +process.env.PORT || 8080, host = process.env.HOST || '0.0.0.0';
  const s = createServer();
  s.listen(port, host, () => console.log(`Empire Capital : http://${host}:${port} · ${s.site.size} fichiers · données dans ${s.cfg.dataDir}`));
  if (s.admin) s.admin.listen(s.adminPort, '127.0.0.1', () => console.log(`Modération : 127.0.0.1:${s.adminPort} (locale uniquement)`));
  const stop = () => { try { s.flushAll(); } catch (e) {} if (s.admin) s.admin.close(); s.close(() => process.exit(0)); setTimeout(() => process.exit(0), 5000).unref(); };
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
}
module.exports = { createServer };
