'use strict';
/* Tests d'attaque du serveur : node --test test/   (aucune dépendance) */
const test = require('node:test'), assert = require('node:assert/strict');
const http = require('http'), fs = require('fs'), os = require('os'), path = require('path'), crypto = require('crypto');
const { createServer } = require('..');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ec-test-'));
const srv = createServer({ env: { DEV: '1', TRUST_PROXY: '1', DATA_DIR: tmp } });
let base, port;
test.before(() => new Promise(r => srv.listen(0, '127.0.0.1', () => { port = srv.address().port; base = 'http://127.0.0.1:' + port; r(); })));
test.after(() => { srv.close(); srv.closeAllConnections && srv.closeAllConnections(); });

let ipN = 1;
function req(method, p, o = {}) {
  return new Promise((resolve, reject) => {
    const headers = Object.assign({ 'X-Forwarded-For': o.ip || ('10.0.0.' + (ipN++ % 250)) }, o.headers || {});
    if (method !== 'GET' && method !== 'HEAD' && !o.noEc) headers['X-EC'] = '1';
    if (o.cookie) headers.Cookie = o.cookie;
    let body = o.raw != null ? o.raw : o.body !== undefined ? JSON.stringify(o.body) : null;
    if (body != null && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
    if (body != null) headers['Content-Length'] = Buffer.byteLength(body);
    const r = http.request({ host: '127.0.0.1', port, method, path: p, headers }, res => {
      const parts = []; res.on('data', c => parts.push(c));
      res.on('end', () => { const t = Buffer.concat(parts).toString('utf8'); let j = null; try { j = JSON.parse(t); } catch (e) {} resolve({ s: res.statusCode, h: res.headers, t, j }); });
    });
    r.on('error', reject); if (body != null) r.write(body); r.end();
  });
}
const b64u = b => Buffer.from(b).toString('base64url');
const cred = () => ({ salt: b64u(crypto.randomBytes(16)), it: 600000, auth: b64u(crypto.randomBytes(32)), vault: b64u(crypto.randomBytes(12)) + '.' + b64u(crypto.randomBytes(48)) });
const ck = r => (r.h['set-cookie'] || []).map(c => c.split(';')[0]).join('; ');
async function newUser(name) { const c = cred(); const r = await req('POST', '/api/register', { body: Object.assign({ u: name }, c) }); assert.equal(r.s, 200, r.t); return { c, cookie: ck(r), name }; }
const ECC = () => 'ECC1.' + b64u(crypto.randomBytes(12)) + '.' + b64u(crypto.randomBytes(64));

test('en-têtes de sécurité sur le jeu', async () => {
  const r = await req('GET', '/', { headers: { 'Accept-Encoding': 'br' } });
  assert.equal(r.s, 200);
  assert.match(r.h['content-security-policy'], /script-src 'sha256-/);
  assert.match(r.h['content-security-policy'], /frame-ancestors 'none'/);
  assert.match(r.h['content-security-policy'], /connect-src 'self'/);
  assert.equal(r.h['x-content-type-options'], 'nosniff');
  assert.equal(r.h['x-frame-options'], 'DENY');
  assert.equal(r.h['cross-origin-opener-policy'], 'same-origin');
  assert.equal(r.h['referrer-policy'], 'no-referrer');
  assert.equal(r.h['content-encoding'], 'br');
  assert.equal(r.h['x-powered-by'], undefined);
  const a = await req('GET', '/api/health');
  assert.equal(a.h['cache-control'], 'no-store'); assert.match(a.h['content-security-policy'], /default-src 'none'/);
});

test('traversée de dossier impossible', async () => {
  for (const p of ['/../server/index.js', '/%2e%2e/server/index.js', '/..%2fserver%2findex.js', '/.well-known/../../package.json', '/..\\..\\server\\index.js', '/%2e%2e%2f%2e%2e%2fetc%2fpasswd', '/server/data/users.json', '/index.html%00.js', '/%c0%ae%c0%ae/etc/passwd']) {
    const r = await req('GET', p);
    assert.ok(r.s === 404 || r.s === 400, p + ' -> ' + r.s);
    assert.ok(!/require\(|root:|"byId"/.test(r.t), 'fuite ' + p);
  }
});

test('méthodes et adresses refusées', async () => {
  assert.equal((await req('PUT', '/', { body: {} })).s, 405);
  assert.equal((await req('DELETE', '/api/health')).s, 405);
  assert.equal((await req('GET', '/api/inexistant')).s, 404);
  assert.equal((await req('GET', '/' + 'a'.repeat(3000))).s, 414);
});

test('inscription : validation des noms et doublons', async () => {
  const u = await newUser('Alice_01');
  assert.match(u.cookie, /^ec_s=[A-Za-z0-9_-]{43}$/);
  const r0 = await req('POST', '/api/register', { body: Object.assign({ u: 'Bob' }, cred()) });
  assert.match(r0.h['set-cookie'][0], /HttpOnly/); assert.match(r0.h['set-cookie'][0], /SameSite=Strict/);
  assert.equal((await req('POST', '/api/register', { body: Object.assign({ u: 'alice_01' }, cred()) })).s, 409);
  for (const bad of ['<script>', 'a', 'admin', 'x'.repeat(21), '../../etc', 'élise', ' bob', 'a"b']) {
    const r = await req('POST', '/api/register', { body: Object.assign({ u: bad }, cred()) });
    assert.ok(r.s === 400, bad + ' -> ' + r.s);
  }
  const c = cred(); c.auth = 'court';
  assert.equal((await req('POST', '/api/register', { body: Object.assign({ u: 'Carl' }, c) })).s, 400);
  const c2 = cred(); c2.it = 1000;   // itérations trop faibles refusées
  assert.equal((await req('POST', '/api/register', { body: Object.assign({ u: 'Carl' }, c2) })).s, 400);
});

test('falsification de requête (CSRF) bloquée', async () => {
  const u = await newUser('Csrf1');
  assert.equal((await req('POST', '/api/logout-all', { cookie: u.cookie, noEc: true, body: {} })).s, 403);
  assert.equal((await req('POST', '/api/logout-all', { cookie: u.cookie, body: {}, headers: { Origin: 'https://pirate.example' } })).s, 403);
  assert.equal((await req('POST', '/api/logout-all', { cookie: u.cookie, body: {}, headers: { 'Sec-Fetch-Site': 'cross-site' } })).s, 403);
  assert.equal((await req('GET', '/api/me', { cookie: u.cookie })).s, 200, 'session toujours valide');
});

test('corps de requête hostiles', async () => {
  assert.equal((await req('POST', '/api/login', { raw: 'u=a', headers: { 'Content-Type': 'text/plain' } })).s, 415);
  assert.equal((await req('POST', '/api/login', { raw: '{"u":' })).s, 400);
  assert.equal((await req('POST', '/api/login', { raw: '{"u":"' + 'a'.repeat(10000) + '"}' })).s, 413);
  let deep = '1'; for (let i = 0; i < 40; i++) deep = '{"a":' + deep + '}';
  assert.equal((await req('POST', '/api/login', { raw: deep })).s, 400);
  const r = await req('POST', '/api/login', { raw: '{"__proto__":{"admin":true},"constructor":{"prototype":{"admin":true}},"u":"x","auth":"y"}' });
  assert.ok(r.s === 400 || r.s === 401);
  assert.equal(({}).admin, undefined);
});

test('connexion : réponses identiques, verrouillage, limitation', async () => {
  const u = await newUser('Dora');
  const p1 = (await req('GET', '/api/prelogin?u=Dora')).j, p2 = (await req('GET', '/api/prelogin?u=Inconnu')).j, p3 = (await req('GET', '/api/prelogin?u=Inconnu')).j;
  assert.equal(p1.salt, u.c.salt); assert.equal(p2.salt.length, 22); assert.equal(p2.salt, p3.salt); assert.equal(p2.it, 600000);
  const wrong = await req('POST', '/api/login', { body: { u: 'Dora', auth: b64u(crypto.randomBytes(32)) } });
  const none = await req('POST', '/api/login', { body: { u: 'Inconnu', auth: b64u(crypto.randomBytes(32)) } });
  assert.equal(wrong.s, 401); assert.equal(none.s, 401); assert.deepEqual(wrong.j, none.j);
  const ok = await req('POST', '/api/login', { body: { u: 'dora', auth: u.c.auth } });
  assert.equal(ok.s, 200); assert.equal(ok.j.vault, u.c.vault);
  for (let i = 0; i < 5; i++) await req('POST', '/api/login', { body: { u: 'Dora', auth: b64u(crypto.randomBytes(32)) } });
  const lock = await req('POST', '/api/login', { body: { u: 'Dora', auth: u.c.auth } });
  assert.equal(lock.s, 429); assert.equal(lock.j.error, 'locked'); assert.ok(lock.h['retry-after']);
  let limited = false;
  for (let i = 0; i < 14; i++) { const r = await req('POST', '/api/login', { ip: '10.9.9.9', body: { u: 'Zz' + i, auth: b64u(crypto.randomBytes(32)) } }); if (r.s === 429) { limited = true; break; } }
  assert.ok(limited, 'force brute limitée par adresse');
});

test('sessions : cookie forgé, déconnexion, tous les appareils', async () => {
  const u = await newUser('Emil');
  assert.equal((await req('GET', '/api/me', { cookie: 'ec_s=' + b64u(crypto.randomBytes(32)) })).s, 401);
  assert.equal((await req('GET', '/api/me', { cookie: 'ec_s=../../x' })).s, 401);
  const s2 = ck(await req('POST', '/api/login', { body: { u: 'Emil', auth: u.c.auth } }));
  assert.equal((await req('POST', '/api/logout', { cookie: u.cookie, body: {} })).s, 200);
  assert.equal((await req('GET', '/api/me', { cookie: u.cookie })).s, 401);
  assert.equal((await req('GET', '/api/me', { cookie: s2 })).s, 200);
  const s3 = ck(await req('POST', '/api/login', { body: { u: 'Emil', auth: u.c.auth } }));
  await req('POST', '/api/logout-all', { cookie: s3, body: {} });
  assert.equal((await req('GET', '/api/me', { cookie: s2 })).s, 401);
});

test('mot de passe : changement et déconnexion des autres appareils', async () => {
  const u = await newUser('Fanny');
  const other = ck(await req('POST', '/api/login', { body: { u: 'Fanny', auth: u.c.auth } }));
  const n = cred();
  assert.equal((await req('POST', '/api/password', { cookie: u.cookie, body: { auth: b64u(crypto.randomBytes(32)), newAuth: n.auth, salt: n.salt, it: n.it, vault: n.vault } })).s, 401);
  assert.equal((await req('POST', '/api/password', { cookie: u.cookie, body: { auth: u.c.auth, newAuth: n.auth, salt: n.salt, it: n.it, vault: n.vault } })).s, 200);
  assert.equal((await req('GET', '/api/me', { cookie: other })).s, 401);
  assert.equal((await req('GET', '/api/me', { cookie: u.cookie })).s, 200);
  assert.equal((await req('POST', '/api/login', { body: { u: 'Fanny', auth: n.auth } })).s, 200);
});

test('cloud : chiffré, isolé par compte, versions, limites', async () => {
  const a = await newUser('Gael'), b = await newUser('Hugo');
  const m = ECC(), d = ECC();
  assert.equal((await req('PUT', '/api/saves/1', { cookie: a.cookie, body: { rev: 0, m, d } })).j.rev, 1);
  assert.equal((await req('PUT', '/api/saves/1', { cookie: a.cookie, body: { rev: 0, m, d } })).s, 409);
  assert.equal((await req('GET', '/api/saves/1', { cookie: a.cookie })).j.d, d);
  assert.equal((await req('GET', '/api/saves/1', { cookie: b.cookie })).s, 404, 'un autre compte ne voit rien');
  assert.equal((await req('GET', '/api/saves/1')).s, 401);
  for (const s of ['7', '0', '..', '..%2f..%2fusers', '1x']) assert.ok([400, 404].includes((await req('GET', '/api/saves/' + s, { cookie: a.cookie })).s), s);
  assert.equal((await req('PUT', '/api/saves/2', { cookie: a.cookie, body: { rev: 0, m: '{"clair":1}', d } })).s, 400, 'contenu en clair refusé');
  const big = 'ECC1.' + 'A'.repeat(16) + '.' + 'A'.repeat(9 * 1024 * 1024);
  assert.equal((await req('PUT', '/api/saves/2', { cookie: a.cookie, body: { rev: 0, m, d: big } })).s, 413);
  assert.equal((await req('GET', '/api/saves', { cookie: a.cookie })).j.saves.length, 1);
  assert.equal((await req('DELETE', '/api/saves/1', { cookie: a.cookie })).s, 200);
  assert.equal((await req('GET', '/api/saves', { cookie: a.cookie })).j.saves.length, 0);
});

test('anti-triche : progression vraisemblable classée, triche écartée', async () => {
  let t = Date.now(); srv.board.now = () => t;
  const u = await newUser('Ines'), C = u.cookie;
  const run = (await req('POST', '/api/runs', { cookie: C, body: { day: 0, nw: 2e6, cash: 2e6, company: 'Ines Corp' } })).j;
  assert.equal(run.ranked, true);
  const cp = async (id, day, nw, dt) => { t += dt; return (await req('POST', `/api/runs/${id}/cp`, { cookie: C, body: { day, nw, cash: nw / 2, company: 'Ines Corp' } })); };
  assert.equal((await cp(run.run, 30, 2.6e6, 60000)).j.ranked, true);
  assert.equal((await cp(run.run, 60, 3.4e6, 60000)).j.ranked, true);
  let top = (await req('GET', '/api/board', { cookie: C })).j;
  assert.equal(top.me.name, 'Ines'); assert.equal(top.me.nw, 3.4e6);
  // fortune multipliée par 1000 en 30 jours
  const r2 = (await req('POST', '/api/runs', { cookie: C, body: { day: 1, nw: 2e6, cash: 2e6, company: 'Triche' } })).j;
  assert.equal((await cp(r2.run, 31, 2e9, 60000)).j.ranked, false);
  // 1 000 jours en 10 secondes
  const r3 = (await req('POST', '/api/runs', { cookie: C, body: { day: 0, nw: 2e6, cash: 2e6, company: 'Vite' } })).j;
  const sp = await cp(r3.run, 1000, 3e6, 10000); assert.equal(sp.j.ranked, false); assert.equal(sp.j.reason, 'speed');
  // ancienne sauvegarde rechargée
  const r4 = (await req('POST', '/api/runs', { cookie: C, body: { day: 0, nw: 2e6, cash: 2e6, company: 'Retour' } })).j;
  await cp(r4.run, 30, 2.2e6, 60000);
  const rb = await cp(r4.run, 20, 2.1e6, 60000); assert.equal(rb.s, 409); assert.equal(rb.j.reason, 'rollback');
  // départ tardif ou fortune de départ gonflée
  assert.equal((await req('POST', '/api/runs', { cookie: C, body: { day: 400, nw: 5e6, cash: 1, company: 'Tard' } })).j.ranked, false);
  assert.equal((await req('POST', '/api/runs', { cookie: C, body: { day: 0, nw: 5e9, cash: 5e9, company: 'Riche' } })).j.ranked, false);
  // valeurs absurdes refusées
  assert.equal((await cp(run.run, 90, Infinity, 60000)).s, 400);
  assert.equal((await req('POST', '/api/runs/' + run.run + '/cp', { cookie: C, body: { day: 90, nw: 'NaN', cash: 1, company: 'x' } })).s, 400);
  // course d'un autre joueur
  const v = await newUser('Jade');
  assert.equal((await req('POST', `/api/runs/${run.run}/cp`, { cookie: v.cookie, body: { day: 90, nw: 4e6, cash: 1, company: 'Vol' } })).s, 404);
  // le classement ne garde que la course propre ; nom d'entreprise nettoyé
  t += 20000; top = (await req('GET', '/api/board')).j;
  assert.equal(top.top.filter(x => x.name === 'Ines').length, 1); assert.equal(top.top.find(x => x.name === 'Ines').nw, 3.4e6);
  const w = await newUser('Kim');
  const r5 = (await req('POST', '/api/runs', { cookie: w.cookie, body: { day: 0, nw: 2e6, cash: 2e6, company: '<img src=x onerror=alert(1)>' } })).j;
  t += 20000; top = (await req('GET', '/api/board')).j;
  assert.ok(!JSON.stringify(top).includes('<'), 'aucun balisage au classement');
  srv.board.now = () => Date.now();
});

test('suppression de compte : tout est effacé', async () => {
  const u = await newUser('Lena');
  await req('PUT', '/api/saves/3', { cookie: u.cookie, body: { rev: 0, m: ECC(), d: ECC() } });
  await req('POST', '/api/runs', { cookie: u.cookie, body: { day: 0, nw: 2e6, cash: 2e6, company: 'Lena SA' } });
  assert.equal((await req('POST', '/api/delete-account', { cookie: u.cookie, body: { auth: b64u(crypto.randomBytes(32)) } })).s, 401);
  const ex = (await req('GET', '/api/export', { cookie: u.cookie })).j;
  assert.equal(ex.compte.nom, 'Lena'); assert.ok(!JSON.stringify(ex).includes(u.c.auth));
  assert.equal((await req('POST', '/api/delete-account', { cookie: u.cookie, body: { auth: u.c.auth } })).s, 200);
  assert.equal((await req('POST', '/api/login', { body: { u: 'Lena', auth: u.c.auth } })).s, 401);
  const left = fs.existsSync(path.join(tmp, 'saves')) ? fs.readdirSync(path.join(tmp, 'saves')).filter(d => fs.existsSync(path.join(tmp, 'saves', d, '3.json'))) : [];
  assert.equal(left.length, 0, 'sauvegarde cloud effacée');
  srv.flushAll();
  assert.ok(!JSON.stringify(JSON.parse(fs.readFileSync(path.join(tmp, 'users.json')))).includes('Lena'));
});

test('stockage : droits restreints, aucun secret en clair', async () => {
  srv.flushAll();
  const mode = f => fs.statSync(path.join(tmp, f)).mode & 0o777;
  assert.equal(mode('users.json'), 0o600); assert.equal(mode('secret.key'), 0o600); assert.equal(fs.statSync(tmp).mode & 0o777, 0o700);
  const users = fs.readFileSync(path.join(tmp, 'users.json'), 'utf8');
  assert.ok(!/"auth"/.test(users));
  const sess = fs.readFileSync(path.join(tmp, 'sessions.json'), 'utf8');
  assert.ok(Object.keys(JSON.parse(sess)).every(k => /^[0-9a-f]{64}$/.test(k)), 'seules les empreintes des jetons sont stockées');
  const audit = fs.readFileSync(path.join(tmp, 'audit.log'), 'utf8');
  assert.ok(!/10\.0\.0\.|127\.0\.0\.1/.test(audit), 'adresses IP non stockées en clair');
});

test('en-tête Host forgé refusé quand ORIGIN est défini', async () => {
  const t2 = fs.mkdtempSync(path.join(os.tmpdir(), 'ec-test2-'));
  const s2 = createServer({ env: { DATA_DIR: t2, ORIGIN: 'https://jeu.exemple.fr' } });
  await new Promise(r => s2.listen(0, '127.0.0.1', r));
  const p2 = s2.address().port;
  const get = host => new Promise(r => http.get({ host: '127.0.0.1', port: p2, path: '/api/health', headers: { Host: host } }, res => { res.resume(); res.on('end', () => r(res)); }));
  assert.equal((await get('pirate.example')).statusCode, 421);
  const ok = await get('jeu.exemple.fr'); assert.equal(ok.statusCode, 200); assert.match(ok.headers['strict-transport-security'], /max-age=63072000/);
  s2.close();
});
