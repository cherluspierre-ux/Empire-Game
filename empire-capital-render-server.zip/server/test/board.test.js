'use strict';
/* Classement : plusieurs classements, égalités, profil, signalements, modération. node --test test/*.test.js */
const test = require('node:test'), assert = require('node:assert/strict');
const http = require('http'), fs = require('fs'), os = require('os'), path = require('path'), crypto = require('crypto');
const { createServer } = require('..');

const TOKEN = crypto.randomBytes(32).toString('base64url');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ec-board-'));
const srv = createServer({ env: { DEV: '1', TRUST_PROXY: '1', DATA_DIR: tmp, ADMIN_TOKEN: TOKEN, ADMIN_PORT: '0' } });
let port, aport, T = Date.UTC(2026, 10, 10, 12);
srv.board.now = () => T;
test.before(() => new Promise(r => srv.listen(0, '127.0.0.1', () => { port = srv.address().port; srv.admin.listen(0, '127.0.0.1', () => { aport = srv.admin.address().port; r(); }); })));
test.after(() => { srv.close(); srv.admin.close(); srv.closeAllConnections(); });

let ipN = 1;
function call(p, method, pth, o = {}) {
  return new Promise((resolve, reject) => {
    const headers = Object.assign({ 'X-Forwarded-For': '10.1.' + (ipN % 250) + '.' + (ipN++ % 250) }, o.headers || {});
    if (method !== 'GET') headers['X-EC'] = '1';
    if (o.cookie) headers.Cookie = o.cookie;
    const body = o.body !== undefined ? JSON.stringify(o.body) : null;
    if (body) { headers['Content-Type'] = 'application/json'; headers['Content-Length'] = Buffer.byteLength(body); }
    const r = http.request({ host: '127.0.0.1', port: p, method, path: pth, headers }, res => { let t = ''; res.on('data', c => t += c); res.on('end', () => { let j = null; try { j = JSON.parse(t); } catch (e) {} resolve({ s: res.statusCode, j, h: res.headers }); }); });
    r.on('error', reject); if (body) r.write(body); r.end();
  });
}
const req = (m, p, o) => call(port, m, p, o);
const adm = (m, p, body, tok = TOKEN) => call(aport, m, p, { body, headers: { Authorization: 'Bearer ' + tok } });
const b64u = b => Buffer.from(b).toString('base64url');
async function user(name) {
  const c = { salt: b64u(crypto.randomBytes(16)), it: 600000, auth: b64u(crypto.randomBytes(32)), vault: b64u(crypto.randomBytes(12)) + '.' + b64u(crypto.randomBytes(48)) };
  const r = await req('POST', '/api/register', { body: Object.assign({ u: name }, c) }); assert.equal(r.s, 200, name + ' ' + JSON.stringify(r.j));
  return { name, cookie: r.h['set-cookie'][0].split(';')[0] };
}
/** Joue une partie propre : points tous les 30 jours avec une croissance donnée. */
async function play(u, { diff = 1, days = 90, growth = 1.1, start = 2e6, company = 'Société ' + u.name, sector = 'resto' } = {}) {
  const r = (await req('POST', '/api/runs', { cookie: u.cookie, body: { day: 0, nw: start, cash: start, company, diff, sector } })).j;
  let nw = start, last;
  for (let d = 30; d <= days; d += 30) { nw *= growth; T += 30000; last = (await req('POST', `/api/runs/${r.run}/cp`, { cookie: u.cookie, body: { day: d, nw, cash: nw / 3, company } })).j; }
  return { run: r.run, nw, last };
}

test('classement général, par difficulté, égalités et notification de rang', async () => {
  const a = await user('Anna'), b = await user('Boris'), c = await user('Chloe'), d = await user('Dylan');
  await play(a, { diff: 1, growth: 1.2 });
  const pb = await play(b, { diff: 3, growth: 1.1 });
  await play(c, { diff: 1, growth: 1.1 });       // même fortune que Boris, atteinte après : derrière
  await play(d, { diff: 0, growth: 1.05 });
  T += 20000;
  const all = (await req('GET', '/api/board')).j;
  assert.deepEqual(all.top.map(x => x.name), ['Anna', 'Boris', 'Chloe', 'Dylan']);
  assert.deepEqual(all.top.map(x => x.rank), [1, 2, 3, 4]);
  const d1 = (await req('GET', '/api/board?d=1')).j;
  assert.deepEqual(d1.top.map(x => x.name), ['Anna', 'Chloe']);
  assert.equal((await req('GET', '/api/board?d=3', { cookie: b.cookie })).j.me.rank, 1);
  assert.equal(pb.last.rank, 1, 'rang renvoyé après un point de contrôle (classement de sa difficulté)');
  assert.equal((await req('GET', '/api/board?b=nimporte&d=9')).j.b, 'all', 'paramètres inconnus ignorés');
});

test('une seule ligne par joueur (sa meilleure partie) ; parties trop courtes non classées', async () => {
  const e = await user('Emma');
  await play(e, { growth: 1.05 }); await play(e, { growth: 1.3 }); await play(e, { growth: 1.01, days: 0 });
  T += 20000;
  const all = (await req('GET', '/api/board')).j;
  assert.equal(all.top.filter(x => x.name === 'Emma').length, 1);
  assert.equal(all.top[0].name, 'Emma');
  const f = await user('Fiona'); await play(f, { days: 0 });
  T += 20000;
  assert.ok(!(await req('GET', '/api/board')).j.top.some(x => x.name === 'Fiona'), 'jour 0 seulement : pas au classement');
});

test('classement « après un an » et saison mensuelle', async () => {
  const g = await user('Gaspard');
  await play(g, { days: 390, growth: 1.08 });
  T += 20000;
  const y1 = (await req('GET', '/api/board?b=y1')).j;
  assert.deepEqual(y1.top.map(x => x.name), ['Gaspard']); assert.ok(y1.top[0].day >= 365);
  const s1 = (await req('GET', '/api/board?b=season')).j;
  assert.ok(s1.top.length >= 5); assert.match(s1.season, /^\d{4}-\d{2}$/);
  T += 40 * 864e5;                                   // le mois suivant : la saison repart de zéro
  assert.equal((await req('GET', '/api/board?b=season')).j.top.length, 0);
  assert.ok((await req('GET', '/api/board')).j.top.length >= 5, 'le classement général reste');
});

test('« autour de moi » au-delà de la 50e place', async () => {
  const many = [];
  for (let i = 0; i < 56; i++) many.push(await user('Joueur' + String(i).padStart(2, '0')));
  for (let i = 0; i < many.length; i++) await play(many[i], { days: 30, growth: 3 - i * 0.02 });
  T += 20000;
  const last = many[many.length - 1];
  const r = (await req('GET', '/api/board', { cookie: last.cookie })).j;
  assert.equal(r.top.length, 50); assert.ok(r.me.rank > 50);
  assert.ok(r.around.some(x => x.me), 'ma ligne est dans « autour de moi »');
  assert.ok(r.around.length >= 4 && r.around.length <= 7);
});

test('profil personnel et fiche publique', async () => {
  const h = await user('Hector');
  await play(h, { diff: 2, growth: 1.1, company: 'Hector & Fils' });
  const r2 = (await req('POST', '/api/runs', { cookie: h.cookie, body: { day: 0, nw: 2e6, cash: 2e6, company: 'Triche', diff: 2 } })).j;
  T += 30000; await req('POST', `/api/runs/${r2.run}/cp`, { cookie: h.cookie, body: { day: 30, nw: 9e9, cash: 1, company: 'Triche' } });
  T += 20000;
  const p = (await req('GET', '/api/profile', { cookie: h.cookie })).j;
  assert.equal(p.games, 2); assert.equal(p.ranked, 1); assert.ok(p.ranks.all >= 1);
  assert.equal(p.runs.find(x => x.company === 'Triche').reason, 'growth');
  assert.equal(p.runs.find(x => x.company === 'Hector & Fils').ranked, true);
  const pub = (await req('GET', '/api/player?u=hector')).j;
  assert.equal(pub.name, 'Hector'); assert.equal(pub.ranked, 1); assert.equal(pub.best.company, 'Hector & Fils');
  assert.ok(!JSON.stringify(pub).includes('Triche'), 'les parties écartées ne sont pas publiques');
  assert.equal((await req('GET', '/api/player?u=personne')).s, 404);
  assert.equal((await req('GET', '/api/profile')).s, 401);
});

test('noms et entreprises injurieux filtrés', async () => {
  for (const n of ['Connard', 'C0nn4rd', 'Hitler88', 'f-u-c-k']) assert.equal((await req('POST', '/api/register', { body: { u: n, salt: b64u(crypto.randomBytes(16)), it: 600000, auth: b64u(crypto.randomBytes(32)), vault: b64u(crypto.randomBytes(12)) + '.' + b64u(crypto.randomBytes(48)) } })).s, 400, n);
  const i = await user('Ines');
  await play(i, { company: 'Salope Industries' });
  T += 20000;
  assert.equal((await req('GET', '/api/player?u=Ines')).j.best.company, 'Entreprise');
});

test('signalements : limites, et mise à l’écart après 5 signalements crédibles', async () => {
  const target = await user('Tricheur');
  await play(target, { growth: 2.9 });
  const fresh = await user('Nouveau');
  assert.equal((await req('POST', '/api/report', { cookie: fresh.cookie, body: { u: 'Tricheur', reason: 'triche' } })).j.ok, 1);
  assert.equal((await req('POST', '/api/report', { cookie: fresh.cookie, body: { u: 'Tricheur', reason: 'triche' } })).j.already, 1, 'un seul signalement par personne');
  assert.equal((await req('POST', '/api/report', { cookie: fresh.cookie, body: { u: 'Nouveau', reason: 'triche' } })).s, 400, 'pas soi-même');
  assert.equal((await req('POST', '/api/report', { cookie: fresh.cookie, body: { u: 'Tricheur', reason: '<x>' } })).s, 400);
  const reporters = [];
  for (let k = 0; k < 5; k++) { const r = await user('Temoin' + k); await play(r, { growth: 1.02 }); srv.acc.byId[srv.acc.byName[r.name.toLowerCase()]].created -= 2 * 864e5; reporters.push(r); }
  for (const r of reporters.slice(0, 4)) await req('POST', '/api/report', { cookie: r.cookie, body: { u: 'Tricheur', reason: 'triche' } });
  T += 20000; assert.ok((await req('GET', '/api/board')).j.top.some(x => x.name === 'Tricheur'), '4 signalements : toujours classé');
  await req('POST', '/api/report', { cookie: reporters[4].cookie, body: { u: 'Tricheur', reason: 'triche' } });
  T += 20000; assert.ok(!(await req('GET', '/api/board')).j.top.some(x => x.name === 'Tricheur'), '5 signalements crédibles : mis à l’écart');
  // la modération lève l'examen
  assert.equal((await adm('POST', '/clear-review', { u: 'Tricheur' })).s, 200);
  T += 20000; assert.ok((await req('GET', '/api/board')).j.top.some(x => x.name === 'Tricheur'));
});

test('modération : accès protégé, bannir, renommer, rétablir une partie', async () => {
  assert.equal((await adm('GET', '/stats', undefined, 'x'.repeat(40))).s, 401, 'mauvais jeton');
  assert.equal((await call(aport, 'GET', '/stats')).s, 401, 'sans jeton');
  const st = (await adm('GET', '/stats')).j; assert.ok(st.comptes > 10 && st.joueurs_classes > 5);
  assert.equal((await adm('POST', '/ban', { u: 'Anna', reason: 'test' })).s, 200);
  T += 20000;
  assert.ok(!(await req('GET', '/api/board')).j.top.some(x => x.name === 'Anna'), 'banni : hors classement');
  assert.equal(srv.board.rankOf(srv.acc.byName.anna, 'all', 'all'), null);
  const anna = await req('POST', '/api/login', { body: { u: 'Anna', auth: 'x' } }); assert.ok(anna.s === 400 || anna.s === 401);
  assert.equal((await req('GET', '/api/player?u=Anna')).s, 404);
  await adm('POST', '/unban', { u: 'Anna' }); T += 20000;
  assert.ok((await req('GET', '/api/player?u=Anna')).j.ranks.all > 0, 'débanni : de retour au classement');
  assert.equal((await adm('POST', '/rename', { u: 'Boris', to: 'Boris_2' })).j.apres, 'Boris_2');
  assert.equal((await adm('POST', '/rename', { u: 'Boris_2', to: 'Connard' })).s, 400, 'nouveau nom filtré aussi');
  T += 20000; assert.ok((await req('GET', '/api/player?u=Boris_2')).j.ranks.all > 0);
  // faux positif : rétablir une partie écartée
  const sus = (await adm('GET', '/flagged')).j; const h = sus.find(x => x.joueur === 'Hector');
  assert.ok(h && h.motif === 'growth');
  assert.equal((await adm('POST', '/run-restore', { run: h.run })).s, 200);
  T += 20000; assert.equal((await req('GET', '/api/player?u=Hector')).j.ranked, 2);
  assert.equal((await adm('POST', '/run-remove', { run: h.run })).s, 200);
  T += 20000; assert.equal((await req('GET', '/api/player?u=Hector')).j.ranked, 1);
  assert.equal((await adm('POST', '/delete-user', { u: 'Dylan', confirm: 'X' })).s, 400, 'suppression : confirmation exigée');
  const log = fs.readFileSync(path.join(tmp, 'audit.log'), 'utf8');
  assert.match(log, /admin_ban/); assert.match(log, /admin_denied/);
});

test('joueur banni : ne peut plus envoyer de partie', async () => {
  const z = await user('Zoe');
  await adm('POST', '/ban', { u: 'Zoe' });
  assert.equal((await req('POST', '/api/runs', { cookie: z.cookie, body: { day: 0, nw: 2e6, cash: 2e6, company: 'Z' } })).j.error, 'banned');
});
